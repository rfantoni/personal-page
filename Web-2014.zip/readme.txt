htpasswd -c .htpasswd rfantoni

TeX4ht:
htlatex  filename "html,2,info"
